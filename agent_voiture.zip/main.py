from telegram_bot import start_bot

if __name__ == "__main__":
    start_bot()
