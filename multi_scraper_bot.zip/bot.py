from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from scraper_generic import search_listings
from loader import load_sources
from utils import parse_query, format_ads
import os
import logging

logging.basicConfig(level=logging.INFO)
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "DUMMY_TOKEN")
sources = load_sources()

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_query = update.message.text
    criteria = parse_query(user_query)
    ads = []

    for source in sources:
        logging.info(f"Recherche via {source['name']}")
        try:
            ads += search_listings(criteria, source)
        except Exception as e:
            logging.error(f"Erreur sur {source['name']} : {e}")

    if ads:
        await update.message.reply_text(format_ads(ads))
    else:
        await update.message.reply_text("Aucune annonce trouvée.")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Bienvenue ! Envoyez vos critères de recherche.")

def start_bot():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.run_polling()
