import os
import requests

API_KEY = os.getenv("DEEPSEEK_API_KEY")

def extraire_criteres(prompt):
    url = "https://platform.deepseek.com/api/chat/completions"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": "Tu es un assistant qui extrait les critères de recherche de véhicule : marque, modèle, prix_max, km_max, lieu"},
            {"role": "user", "content": prompt}
        ]
    }
    response = requests.post(url, headers=headers, json=data)
    response.raise_for_status()
    return response.json()["choices"][0]["message"]["content"]
