import requests
from urllib.parse import urlencode

def search_listings(criteria, config):
    url = config["base_url"]
    method = config.get("method", "GET").upper()
    params_template = config.get("params_template", {})

    # Remplacer les placeholders dans params_template par criteria
    params = {}
    for key, template in params_template.items():
        try:
            val = template.format(**criteria)
            if val:
                params[key] = val
        except KeyError:
            pass  # Critère absent -> on ignore ce paramètre

    if method == "GET":
        full_url = f"{url}?{urlencode(params)}"
        resp = requests.get(full_url)
    else:
        resp = requests.post(url, data=params)

    if resp.status_code != 200:
        return []

    # Appel dynamique du parseur
    parser_func = globals().get(config.get("parser"))
    if parser_func:
        return parser_func(resp.text)
    return []

# Exemples de fonctions de parsing (à adapter selon le vrai HTML)
def parse_leboncoin(html):
    # Simulé pour l'exemple
    return [{
        "title": "Peugeot 208 - LBC",
        "price": "9 000 €",
        "url": "https://www.leboncoin.fr/voitures/123456",
        "location": "Paris",
        "year": "2020",
        "mileage": "45 000 km"
    }]

def parse_auto29(html):
    return [{
        "title": "Renault Clio - Auto29",
        "price": "8 500 €",
        "url": "https://www.auto-occasion-29.com/voiture/1234",
        "location": "Brest",
        "year": "2019",
        "mileage": "60 000 km"
    }]
