import os
from telegram.ext import Updater, MessageHandler, Filters
from ia_extractor import extraire_criteres

def handle_message(update, context):
    user_input = update.message.text
    criteres = extraire_criteres(user_input)
    update.message.reply_text(f"Critères extraits :\n{criteres}")

def start_bot():
    TOKEN = os.getenv("TELEGRAM_TOKEN")
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))
    updater.start_polling()
    updater.idle()
