def parse_query(query):
    # Très simple, à étoffer selon besoin
    # Exemple : "peugeot km_max=50000 year_min=2015 fuel=diesel"
    parts = query.split()
    criteria = {"keywords": parts[0]}
    for part in parts[1:]:
        if '=' in part:
            k, v = part.split('=', 1)
            criteria[k] = v
    return criteria

def format_ads(ads):
    return "\n\n".join([
        f"{ad['title']}\n{ad['price']} - {ad['location']}\n{ad['year']} - {ad['mileage']}\n{ad['url']}"
        for ad in ads
    ])
