import yaml

def load_sources(config_path="sources.yml"):
    with open(config_path, "r") as f:
        data = yaml.safe_load(f)
    return [src for src in data["sources"] if src.get("enabled")]
